package com.example.udon;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class MainActivity extends AppCompatActivity {

    EditText editComment;
    String selectedChoice = "";
    String serverUrl = "http://10.0.2.2:9999/Udon/SelectServlet";
    Button btnA, btnB, btnC, btnD, btnSubmit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editComment = findViewById(R.id.editComment);
        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        btnSubmit = findViewById(R.id.btnSubmit);

        btnA.setOnClickListener(v -> updateSelection("a", btnA));
        btnB.setOnClickListener(v -> updateSelection("b", btnB));
        btnC.setOnClickListener(v -> updateSelection("c", btnC));
        btnD.setOnClickListener(v -> updateSelection("d", btnD));

        btnSubmit.setOnClickListener(v -> {
            if (selectedChoice.isEmpty()) {
                Toast.makeText(this, "Please select a brand first!", Toast.LENGTH_SHORT).show();
            } else {
                sendVoteToServer();
            }
        });
    }

    void updateSelection(String choice, Button selectedBtn) {
        selectedChoice = choice;
        int neutral = Color.parseColor("#88FFFFFF");
        btnA.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnB.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnC.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnD.setBackgroundTintList(ColorStateList.valueOf(neutral));

        selectedBtn.setBackgroundTintList(ColorStateList.valueOf(Color.LTGRAY));
    }

    void sendVoteToServer() {
        String comment = editComment.getText().toString();
        String urlWithParams = serverUrl + "?choice=" + selectedChoice + "&comment=" + Uri.encode(comment);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, urlWithParams,
                response -> {
                    // Clean up screen
                    selectedChoice = "";
                    editComment.setText("");
                    resetButtons();

                    // Success message
                    Toast.makeText(this, "Vote Submitted! Returning to Login", Toast.LENGTH_SHORT).show();

                    // Back to LoginActivity
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);

                    //Can't go back to the vote screen
                    finish();

                },

                error -> {
                    Log.e("UdonError", error.toString());
                    Toast.makeText(this, "Error: Check Tomcat!", Toast.LENGTH_SHORT).show();
                });

        Volley.newRequestQueue(this).add(stringRequest);
    }

    void resetButtons() {
        int neutral = Color.parseColor("#88FFFFFF");
        btnA.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnB.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnC.setBackgroundTintList(ColorStateList.valueOf(neutral));
        btnD.setBackgroundTintList(ColorStateList.valueOf(neutral));
    }
}