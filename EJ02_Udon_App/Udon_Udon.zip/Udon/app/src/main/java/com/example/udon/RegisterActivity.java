package com.example.udon;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    // 1. Declare variables for all your UI elements
    EditText regUsername, regPassword, regFullName;
    Button btnRegister;
    TextView tvBackToLogin;

    // Use 10.0.2.2 for Android Emulator to talk to your local laptop server
    String url = "http://10.0.2.2:9999/Udon/RegisterServlet";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 2. Link the Java variables to your XML IDs (MUST MATCH EXACTLY)
        regUsername = findViewById(R.id.regUsername);
        regPassword = findViewById(R.id.regPassword);
        regFullName = findViewById(R.id.regFullName);
        btnRegister = findViewById(R.id.btnRegister);
        tvBackToLogin = findViewById(R.id.tvBackToLogin);

        // 3. Set the listener for the button
        btnRegister.setOnClickListener(v -> {
            // TEST: This Toast will tell us if the button is even connected
            Toast.makeText(this, "Attempting to Register...", Toast.LENGTH_SHORT).show();

            sendRegistrationRequest();
        });

        // Link back to Login
        tvBackToLogin.setOnClickListener(v -> finish());
    }

    private void sendRegistrationRequest() {
        String u = regUsername.getText().toString().trim();
        String p = regPassword.getText().toString().trim();
        String f = regFullName.getText().toString().trim();

        if (u.isEmpty() || p.isEmpty()) {
            Toast.makeText(this, "Fields cannot be empty!", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest req = new StringRequest(Request.Method.POST, url,
                response -> {
                    // Check if Servlet sent "Success"
                    if (response.trim().equalsIgnoreCase("Success")) {
                        Toast.makeText(this, "Welcome!", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                        finish();
                    } else if (response.trim().equalsIgnoreCase("Exists")) {
                        Toast.makeText(this, "That username is taken!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Error: " + response, Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Toast.makeText(this, "Connection Error! Is Tomcat on?", Toast.LENGTH_LONG).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                // Match these keys to your Servlet: request.getParameter("username")
                params.put("username", u);
                params.put("password", p);
                params.put("fullname", f);
                return params;
            }
        };

        Volley.newRequestQueue(this).add(req);
    }
}