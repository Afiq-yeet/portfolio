package com.example.udon;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // --- LOGIN LOGIC ---
        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String user = ((EditText)findViewById(R.id.editUser)).getText().toString();
            String pass = ((EditText)findViewById(R.id.editPass)).getText().toString();

            String url = "http://10.0.2.2:9999/Udon/LoginServlet?username=" + user + "&password=" + pass;

            StringRequest req = new StringRequest(Request.Method.GET, url,
                    response -> {
                        if (response.trim().equalsIgnoreCase("Success")) {
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                        }
                    },
                    error -> Toast.makeText(this, "Server Error: Check Tomcat", Toast.LENGTH_SHORT).show()
            );
            Volley.newRequestQueue(this).add(req);
        });

        // REGISTER NAVIGATION --
        findViewById(R.id.btnGoToRegister).setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }
}